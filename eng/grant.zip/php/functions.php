<?php 
	function includeWithVars($vars, $url){
		include $url;
	}

	function curPage(){
		if(!array_key_exists('cur', $_GET))
			return 'home';
		return $_GET['cur'];
	}

	function subPage(){
		if(!array_key_exists('sub', $_GET))
			return 'index.php';
		return $_GET['sub'].'.php';
	}

	function render($curPage, $subPage){
		if($curPage == 'home')
			include "home.php";
		else 
			include $curPage.'/'.$subPage;
	}

	function getLan(){
		if(!array_key_exists('lan', $_GET))
			return 'geo';
		return $_GET['lan'];
	}

	function addSubMenu($arr, $id){
		$str = "<ul id = '$id' class='subMenu'>";
		foreach($arr as $li){
			$str .= "<li class='link'>
			<a href='#'>
			$li
			</a>
			</li>";
		}
		$str .= "</ul>"; 
		echo $str;
	}
?>
<!DOCTYPE HTML>
<html>
<head>
	<title>Sample</title>
	<meta charset="utf-8"></meta>
	<link rel="stylesheet" type="text/css" href="stylesheets/w3.css">
	<link rel="stylesheet" type="text/css" href="stylesheets/style.css">
	<script type="text/javascript" src="js/jquery.min.js"></script>
</head>
<body>
	<header>
		<table class="headerTable">
			<tr>
				<td>
					<ul class="navigation">
						<!-- 1 -->
						<li 
						<?php 
						$class = "home inline nav link";
						if($curPage == 'home') 
							echo 'class="'.$class.' cur underline"'; 
						else 
							echo 'class="'.$class.'"';
						?>
						>
							<a href="/">მთავარი</a>
						</li>

						<!-- 2 -->
						<li 
						<?php 
						$class = "geo inline nav link";
						if($curPage == 'geo') 
							echo 'class="'.$class.' cur underline"'; 
						else 
							echo 'class="'.$class.'"';
						?>
						>
							<a href="#">საქართველო</a>
							<?php 
							addSubMenu(['50 ფაქტი საქართველოზე', 'ქართული სამზარეულო', 'საქართველო და ღვინო'], 'geo'); 
							?>
						</li>

						<!-- 3 -->
						<li 
						<?php 
						$class = "instr inline nav link";
						if($curPage == 'instr') 
							echo 'class="'.$class.' cur underline"'; 
						else 
							echo 'class="'.$class.'"';
						?>
						>
							<a href="/?cur=instr">ინსტრუქციები</a>
							<?php 
							addSubMenu(['Виза в Грузию', 'Таможенные правила', 'Пересечение границы', 'Железная дорога в Грузии', 'Путешествующим на автомобиле'], 'instr'); 
							?>
						</li>

						<!-- 4 -->
						<li 
						<?php 
						$class = "tours inline nav link";
						if($curPage == 'tours') 
							echo 'class="'.$class.' cur underline"'; 
						else 
							echo 'class="'.$class.'"';
						?>
						>
							<a href="/?cur=tours">ტურები</a>
						</li>

						<!-- 5 -->
						<li 
						<?php 
						$class = "advs inline nav link";
						if($curPage == 'advs')
							echo 'class="'.$class.' cur underline"'; 
						else
							echo 'class="'.$class.'"';
						?>
						>
							<a href="/?cur=advs">თავგადასავლები</a>
						</li>
					</ul>
					<script type="text/javascript" src="js/header.js"></script>
				</td>
				<td>
					<ul class="lan">
						<li>GEO</li>
						<li>ENG</li>
						<li>RUS</li>
					</ul>
				<td>
			</tr>
		</table>
	</header>
	<div class="content">
<footer>
			<table class="socialNetworks">
				<tr>
					<td><div class="socNet" id="fb"></div></td>
					<td><div class="socNet" id="insta"></div></td>
					<td><div class="socNet" id="mail"></div></td>
				</tr>
			</table>
			<p class="footerText">2016 &copy; this.com | All rights reserved</p>
			<script type="text/javascript" src="js/footer.js"></script>
		</footer>
	</div>
</body>
</html>